"""Experimental Service

This module provides the ExperimentalService class that exposes experimental features
from the Render SDK.
"""

from typing import TYPE_CHECKING

from render_sdk.experimental.key_value.api import KeyValueApi
from render_sdk.experimental.key_value.provider import KeyValueProvider
from render_sdk.experimental.object.client import ObjectClient
from render_sdk.experimental.sandbox.client import SandboxClient

if TYPE_CHECKING:
    from render_sdk.client.client import Client


class StorageService:
    """Storage Service

    Provides access to experimental storage features.

    Example:
        ```python
        # Access object storage
        await client.experimental.storage.objects.put(
            owner_id="tea-xxxxx",
            region="oregon",
            key="file.png",
            data=b"content"
        )
        ```
    """

    def __init__(self, client: "Client"):
        """Initialize the storage service.

        Args:
            client: The Render client instance
        """
        self.objects = ObjectClient(
            client.internal,
            default_owner_id=client.owner_id,
            default_region=client.region,
        )


class ExperimentalService:
    """Experimental Service

    Provides access to experimental Render SDK features.

    Features in this namespace may change or be removed without a migration plan.
    When a feature stabilizes, it will be promoted to the main SDK namespace.

    Example:
        ```python
        from render_sdk import RenderAsync

        render = RenderAsync()

        # Access experimental object storage
        await render.experimental.storage.objects.put(
            owner_id="tea-xxxxx",
            region="oregon",
            key="file.png",
            data=b"content"
        )

        # Access experimental Key Value support
        from render_sdk.experimental.key_value import NameOwnerIdOptions
        redis = await render.experimental.key_value.new_client(
            NameOwnerIdOptions(name="my-cache")
        )
        ```
    """

    def __init__(self, client: "Client"):
        """Initialize the experimental service.

        Args:
            client: The Render client instance
        """
        self.storage = StorageService(client)
        self.key_value = KeyValueProvider(
            KeyValueApi(client.internal),
            default_owner_id=client.owner_id,
        )
        self.sandboxes = SandboxClient(
            client.internal,
            default_owner_id=client.owner_id,
            default_region=client.region,
        )
