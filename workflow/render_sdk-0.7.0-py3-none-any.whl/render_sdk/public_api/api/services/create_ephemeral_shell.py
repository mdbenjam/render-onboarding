from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_ephemeral_shell_body import CreateEphemeralShellBody
from ...models.create_ephemeral_shell_response_201 import CreateEphemeralShellResponse201
from ...models.error import Error
from ...types import Response


def _get_kwargs(
    service_id: str,
    *,
    body: CreateEphemeralShellBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": f"/services/{service_id}/ephemeral-shell",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[CreateEphemeralShellResponse201, Error]]:
    if response.status_code == 201:
        response_201 = CreateEphemeralShellResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = Error.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = Error.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = Error.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if response.status_code == 503:
        response_503 = Error.from_dict(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[CreateEphemeralShellResponse201, Error]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    service_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
    body: CreateEphemeralShellBody,
) -> Response[Union[CreateEphemeralShellResponse201, Error]]:
    """Create an ephemeral shell instance

     Create an ephemeral instance of your service. You can ssh into it, but it won't receive traffic.

    Args:
        service_id (str):
        body (CreateEphemeralShellBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[CreateEphemeralShellResponse201, Error]]
    """

    kwargs = _get_kwargs(
        service_id=service_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    service_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
    body: CreateEphemeralShellBody,
) -> Optional[Union[CreateEphemeralShellResponse201, Error]]:
    """Create an ephemeral shell instance

     Create an ephemeral instance of your service. You can ssh into it, but it won't receive traffic.

    Args:
        service_id (str):
        body (CreateEphemeralShellBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[CreateEphemeralShellResponse201, Error]
    """

    return sync_detailed(
        service_id=service_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    service_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
    body: CreateEphemeralShellBody,
) -> Response[Union[CreateEphemeralShellResponse201, Error]]:
    """Create an ephemeral shell instance

     Create an ephemeral instance of your service. You can ssh into it, but it won't receive traffic.

    Args:
        service_id (str):
        body (CreateEphemeralShellBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[CreateEphemeralShellResponse201, Error]]
    """

    kwargs = _get_kwargs(
        service_id=service_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    service_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
    body: CreateEphemeralShellBody,
) -> Optional[Union[CreateEphemeralShellResponse201, Error]]:
    """Create an ephemeral shell instance

     Create an ephemeral instance of your service. You can ssh into it, but it won't receive traffic.

    Args:
        service_id (str):
        body (CreateEphemeralShellBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[CreateEphemeralShellResponse201, Error]
    """

    return (
        await asyncio_detailed(
            service_id=service_id,
            client=client,
            body=body,
        )
    ).parsed
