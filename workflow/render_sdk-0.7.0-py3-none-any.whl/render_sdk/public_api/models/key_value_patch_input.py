from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.key_value_plan import KeyValuePlan
from ..models.maxmemory_policy import MaxmemoryPolicy
from ..models.persistence_mode import PersistenceMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.cidr_block_and_description import CidrBlockAndDescription


T = TypeVar("T", bound="KeyValuePATCHInput")


@_attrs_define
class KeyValuePATCHInput:
    """Input type for updating a Key Value instance

    Attributes:
        name (Union[Unset, str]): The name of the Key Value instance
        plan (Union[Unset, KeyValuePlan]):
        maxmemory_policy (Union[Unset, MaxmemoryPolicy]): The eviction policy for the Key Value instance
        persistence_mode (Union[Unset, PersistenceMode]): The persistence mode for the Key Value instance. The default
            for paid instances is journal_snapshot (both journaling and snapshots). Only turn off persistence if you're
            using this Key Value instance as a cache and are okay with losing data. Free instances do not have persistence.
        ip_allow_list (Union[Unset, list['CidrBlockAndDescription']]):
    """

    name: Union[Unset, str] = UNSET
    plan: Union[Unset, KeyValuePlan] = UNSET
    maxmemory_policy: Union[Unset, MaxmemoryPolicy] = UNSET
    persistence_mode: Union[Unset, PersistenceMode] = UNSET
    ip_allow_list: Union[Unset, list["CidrBlockAndDescription"]] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        plan: Union[Unset, str] = UNSET
        if not isinstance(self.plan, Unset):
            plan = self.plan.value

        maxmemory_policy: Union[Unset, str] = UNSET
        if not isinstance(self.maxmemory_policy, Unset):
            maxmemory_policy = self.maxmemory_policy.value

        persistence_mode: Union[Unset, str] = UNSET
        if not isinstance(self.persistence_mode, Unset):
            persistence_mode = self.persistence_mode.value

        ip_allow_list: Union[Unset, list[dict[str, Any]]] = UNSET
        if not isinstance(self.ip_allow_list, Unset):
            ip_allow_list = []
            for ip_allow_list_item_data in self.ip_allow_list:
                ip_allow_list_item = ip_allow_list_item_data.to_dict()
                ip_allow_list.append(ip_allow_list_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if plan is not UNSET:
            field_dict["plan"] = plan
        if maxmemory_policy is not UNSET:
            field_dict["maxmemoryPolicy"] = maxmemory_policy
        if persistence_mode is not UNSET:
            field_dict["persistenceMode"] = persistence_mode
        if ip_allow_list is not UNSET:
            field_dict["ipAllowList"] = ip_allow_list

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.cidr_block_and_description import CidrBlockAndDescription

        d = dict(src_dict)
        name = d.pop("name", UNSET)

        _plan = d.pop("plan", UNSET)
        plan: Union[Unset, KeyValuePlan]
        if isinstance(_plan, Unset):
            plan = UNSET
        else:
            plan = KeyValuePlan(_plan)

        _maxmemory_policy = d.pop("maxmemoryPolicy", UNSET)
        maxmemory_policy: Union[Unset, MaxmemoryPolicy]
        if isinstance(_maxmemory_policy, Unset):
            maxmemory_policy = UNSET
        else:
            maxmemory_policy = MaxmemoryPolicy(_maxmemory_policy)

        _persistence_mode = d.pop("persistenceMode", UNSET)
        persistence_mode: Union[Unset, PersistenceMode]
        if isinstance(_persistence_mode, Unset):
            persistence_mode = UNSET
        else:
            persistence_mode = PersistenceMode(_persistence_mode)

        ip_allow_list = []
        _ip_allow_list = d.pop("ipAllowList", UNSET)
        for ip_allow_list_item_data in _ip_allow_list or []:
            ip_allow_list_item = CidrBlockAndDescription.from_dict(ip_allow_list_item_data)

            ip_allow_list.append(ip_allow_list_item)

        key_value_patch_input = cls(
            name=name,
            plan=plan,
            maxmemory_policy=maxmemory_policy,
            persistence_mode=persistence_mode,
            ip_allow_list=ip_allow_list,
        )

        key_value_patch_input.additional_properties = d
        return key_value_patch_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
