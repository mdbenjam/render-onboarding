from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="InstanceCountChanged")


@_attrs_define
class InstanceCountChanged:
    """
    Attributes:
        from_instances (int):
        to_instances (int):
    """

    from_instances: int
    to_instances: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from_instances = self.from_instances

        to_instances = self.to_instances

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "fromInstances": from_instances,
                "toInstances": to_instances,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        from_instances = d.pop("fromInstances")

        to_instances = d.pop("toInstances")

        instance_count_changed = cls(
            from_instances=from_instances,
            to_instances=to_instances,
        )

        instance_count_changed.additional_properties = d
        return instance_count_changed

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
